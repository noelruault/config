# Readme

## Configuration

Makefile:
    MAIN_JS_FILE
    PACKAGE_MANAGER

wrangler.toml:
    main
